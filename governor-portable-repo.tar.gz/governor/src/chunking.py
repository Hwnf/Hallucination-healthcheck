import math
from typing import Optional

def preferred_target(task_id: str, i: int, low: int, high: int) -> int:
    span = max(1, high - low + 1)
    h = abs(hash(f"{task_id}:{i}")) % span
    return low + h


def plan_chunks(task_id: str, remaining_tokens: int, remaining_budget_tokens: Optional[int], reserve_floor_tokens: int, overhead: float = 1.1, target_low: int = 60000, target_high: int = 80000, hard_cap_effective: int = 125000, context_window_tokens: Optional[int] = None, context_frac: float = 0.8):
    """Plan chunk sizes respecting overhead and caps.

    Returns a dict with runtime_cap_effective, raw_runtime_cap, chunks, and inputs.
    """
    caps = [hard_cap_effective]
    if remaining_budget_tokens is not None:
        caps.append(max(0, remaining_budget_tokens - reserve_floor_tokens))
    if context_window_tokens:
        caps.append(int(context_frac * context_window_tokens))
    runtime_cap_effective = min(caps)
    raw_runtime_cap = max(1, int(runtime_cap_effective / overhead))
    chunks = []
    i = 0
    rem = remaining_tokens
    while rem > 0:
        pref = preferred_target(task_id, i, target_low, target_high)
        sz = min(rem, raw_runtime_cap, pref)
        if sz <= 0:
            break
        chunks.append(int(sz))
        rem -= sz
        i += 1
    return {
        'task_id': task_id,
        'remaining_tokens': remaining_tokens,
        'remaining_budget_tokens': remaining_budget_tokens,
        'reserve_floor_tokens': reserve_floor_tokens,
        'overhead': overhead,
        'target_low': target_low,
        'target_high': target_high,
        'hard_cap_effective': hard_cap_effective,
        'context_window_tokens': context_window_tokens,
        'context_frac': context_frac,
        'runtime_cap_effective': runtime_cap_effective,
        'raw_runtime_cap': raw_runtime_cap,
        'chunks': chunks
    }
