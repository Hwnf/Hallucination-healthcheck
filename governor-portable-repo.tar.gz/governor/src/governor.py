import os
import json
import logging
import time
from pathlib import Path

logger = logging.getLogger('governor')
logging.basicConfig(level=logging.INFO)
CONFIG_PATH = Path(os.getenv('GOVERNOR_CONFIG') or './config/governor_config.json')
if CONFIG_PATH.exists():
    CONFIG = json.loads(CONFIG_PATH.read_text())
else:
    CONFIG = {}

MODE = CONFIG.get('enforcement_mode','shadow')
QUEUE_DIR = Path(os.getenv('GOVERNOR_CHECKPOINT_DIR') or CONFIG.get('durable_queue',{}).get('host_checkpoint_dir') or './data/queue')
SHADOW_REPORT = Path(os.getenv('GOVERNOR_SHADOW_REPORT') or CONFIG.get('startup',{}).get('shadow_report_path') or './data/logs/shadow_report.jsonl')
TOKEN_BUCKET = None
try:
    from token_bucket import TokenBucket
    TOKEN_BUCKET = TokenBucket(CONFIG.get('tpm',500000), capacity=CONFIG.get('bucket_capacity',500000))
except Exception:
    TOKEN_BUCKET = None

RESULTS_DIR = Path(os.getenv('GOVERNOR_RESULTS_DIR') or './data/results')

def write_shadow(obj):
    SHADOW_REPORT.parent.mkdir(parents=True, exist_ok=True)
    with open(SHADOW_REPORT,'a') as f:
        f.write(json.dumps(obj)+"\n")

def process_chunk_file(p:Path):
    # read chunk
    obj = json.loads(p.read_text())
    est = obj.get('chunk_est')
    # be tolerant: payload may be missing, treat top-level as payload
    task = obj.get('payload') or obj
    task_id = task.get('task_id')
    state_file = p.with_suffix('.status')
    # check reserve_floor_tokens
    reserve_floor = CONFIG.get('reserve_floor_tokens',0)
    if TOKEN_BUCKET:
        avail = TOKEN_BUCKET.available()
        would_reserve = (avail >= est and (avail-est)>=reserve_floor)
    else:
        would_reserve = False
    # write running status
    state = {'task_id':task_id,'chunk':p.name,'state':'running' if would_reserve else 'paused','est':est,'would_reserve':would_reserve,'ts':time.time()}
    state_file.write_text(json.dumps(state))
    write_shadow({'task_id':task_id,'chunk':p.name,'would_reserve':would_reserve,'est':est,'avail': TOKEN_BUCKET.available() if TOKEN_BUCKET else None,'mode':MODE})
    if would_reserve and TOKEN_BUCKET:
        # reserve and simulate processing
        TOKEN_BUCKET.reserve(est)
        # simulate work
        time.sleep(0.1)
        # mark done
        state['state']='done'
        state['finished_at']=time.time()
        state_file.write_text(json.dumps(state))
        # move or remove chunk file
        p.unlink()
    else:
        # leave file queued for later
        pass

def worker_loop():
    logger.info(f'governor worker starting mode={MODE}')
    logger.info(f'config_path={CONFIG_PATH} backend={CONFIG.get("durable_queue",{}).get("backend")} redis_queue_key={CONFIG.get("durable_queue",{}).get("redis_queue_key")} shadow_report={SHADOW_REPORT}')
    try:
        import redis
        redis_url = os.environ.get('REDIS_URL')
        r = redis.from_url(redis_url, socket_connect_timeout=2, socket_timeout=2) if redis_url else None
    except Exception:
        r = None

    # periodic status logger (runs in separate thread)
    try:
        import threading
        def status_logger():
            import time
            last_error = None
            while True:
                try:
                    qlen = r.llen(CONFIG.get('durable_queue',{}).get('redis_queue_key','governor:queue')) if r else None
                    delayed = r.zcard(CONFIG.get('durable_queue',{}).get('delayed_queue_key','governor:delayed')) if r else None
                    enforce_env = os.getenv('GOVERNOR_ENFORCE','false').lower()=='true'
                    test_mode = os.getenv('GOVERNOR_TEST_MODE','false').lower()=='true'
                    logger.info(f'STATUS queue_len={qlen} delayed_len={delayed} enforce={enforce_env} test_mode={test_mode} last_error={last_error}')
                except Exception as e:
                    logger.exception('status logger error')
                time.sleep(30)
        t = threading.Thread(target=status_logger, daemon=True)
        t.start()
    except Exception:
        logger.exception('failed to start status logger')

    while True:
        try:
            # Prefer Redis blocking pop when configured
            if r and CONFIG.get('durable_queue',{}).get('backend')=='redis':
                # determine redis queue key; allow env override for enforce worker
                key = os.getenv('GOVERNOR_REDIS_QUEUE_KEY') or CONFIG.get('durable_queue',{}).get('redis_queue_key','governor:queue')
                logger.info(f'attempting BLPOP key={key}')
                if r and CONFIG.get('durable_queue',{}).get('backend')=='redis':
                    # move due delayed items into the main queue
                    try:
                        zkey = CONFIG.get('durable_queue',{}).get('delayed_queue_key','governor:delayed')
                        now = int(time.time())
                        # members are task_ids
                        due = r.zrangebyscore(zkey, 0, now)
                        if due:
                            for task_id_member in due:
                                try:
                                    task_key = f"governor:task:{task_id_member}"
                                    payload_json = r.get(task_key)
                                    if payload_json:
                                        r.rpush(key, payload_json)
                                        r.zrem(zkey, task_id_member)
                                        # optional: delete the task record after enqueue
                                        # r.delete(task_key)
                                        logger.info(f'moved delayed task to queue task_id={task_id_member}')
                                    else:
                                        # no payload record; remove zset member to avoid retrying forever
                                        r.zrem(zkey, task_id_member)
                                        logger.warning(f'delayed task {task_id_member} missing payload; removed from zset')
                                except Exception:
                                    logger.exception('failed moving delayed item')
                    except Exception:
                        logger.exception('delayed queue check failed')

                item = r.blpop([key], timeout=1)
                if item:
                    try:
                        raw = item[1]
                        logger.info(f'popped bytes_len={len(raw)}')
                        # parse and persist
                        obj = json.loads(raw)
                        # log raw object keys for deterministic debugging
                        try:
                            raw_keys = list(obj.keys()) if isinstance(obj, dict) else ['<not_dict>']
                        except Exception:
                            raw_keys = ['<error>']
                        logger.info(f'RAW_OBJ_KEYS={raw_keys} task_raw_len={len(raw)}')
                        task_id = obj.get('task_id') or obj.get('payload',{}).get('task_id')
                        write_shadow({'task_id':task_id,'event':'popped','bytes_len':len(raw),'ts':time.time()})
                        enforce_env = os.getenv('GOVERNOR_ENFORCE','false').lower()=='true'
                        # Read task object and canary raw value
                        task_obj = obj.get('payload') or obj
                        if isinstance(task_obj, dict):
                            canary_raw = task_obj.get('canary','__missing__')
                        else:
                            canary_raw = '__not_dict__'
                        # normalize None -> False and compute coerced boolean
                        if canary_raw is None:
                            logger.warning(f'canary_null_detected task_id={task_id}')
                            canary_raw = False
                        canary_flag = bool(canary_raw) if canary_raw not in ('__missing__','__not_dict__') else False
                        # Chunk-splitting: if task declares large estimated_input_tokens, plan chunks and write chunk files
                        try:
                            est_tokens = task_obj.get('estimated_input_tokens') if isinstance(task_obj, dict) else None
                            max_per_req = CONFIG.get('max_estimated_tokens_per_request')
                            overhead = CONFIG.get('token_estimate_overhead', 1.1)
                            reserve_floor = CONFIG.get('reserve_floor_tokens', 5000)
                            remaining_budget = None
                            if TOKEN_BUCKET:
                                try:
                                    remaining_budget = TOKEN_BUCKET.available()
                                except Exception:
                                    remaining_budget = None
                            split_threshold = CONFIG.get('chunk_split_threshold', 80000)
                            if est_tokens and est_tokens > split_threshold:
                                from agent_hub import chunking
                                plan = chunking.plan_chunks(task_id, est_tokens, remaining_budget, reserve_floor, overhead, target_low=CONFIG.get('chunk_target_low_tokens',60000), target_high=CONFIG.get('chunk_target_high_tokens',80000), hard_cap_effective=CONFIG.get('chunk_hard_cap_tokens',125000), context_window_tokens=CONFIG.get('chunk_context_window_tokens'), context_frac=CONFIG.get('chunk_context_fraction',0.8))
                                plan_report = dict(plan); plan_report['remaining_budget_tokens']=remaining_budget; write_shadow({'event':'chunk_plan','task_id':task_id,'plan':plan_report,'ts':time.time()})
                                QUEUE_DIR.mkdir(parents=True, exist_ok=True)
                                for i,sz in enumerate(plan['chunks']):
                                    chunk_id = f"{task_id}-chunk-{i}"
                                    payload = dict(task_obj) if isinstance(task_obj, dict) else {}
                                    payload['chunk_index'] = i
                                    payload['total_chunks'] = len(plan['chunks'])
                                    chunk_fname = QUEUE_DIR / f"{chunk_id}.json"
                                    chunk_obj = {'chunk_est': int(sz), 'payload': payload}
                                    chunk_fname.write_text(json.dumps(chunk_obj))
                                    status = QUEUE_DIR / f"{chunk_id}.status"
                                    status.write_text(json.dumps({'task_id':chunk_id,'chunk':chunk_fname.name,'state':'queued','est':int(sz),'ts':time.time()}))
                                logger.info(f'PLANNED_AND_WRITTEN_CHUNKS task_id={task_id} num_chunks={len(plan["chunks"]) } raw_runtime_cap={plan["raw_runtime_cap"]} runtime_cap_effective={plan["runtime_cap_effective"]}')
                                try:
                                    fname.unlink()
                                except Exception:
                                    pass
                                continue
                        except Exception:
                            logger.exception('chunk split check failed')
                        # create a temp file for compatibility with existing process_chunk_file
                        fname = QUEUE_DIR / f"{task_id}.json"
                        fname.write_text(raw.decode('utf-8'))
                        # Evaluate mode explicitly at runtime to avoid races
                        # enforce only when env says enforce AND task is canary
                        effective_mode = 'enforce' if (enforce_env and canary_flag) else 'shadow'
                        # Log both the coerced boolean and the raw value (never print raw as canary=)
                        logger.info(f'MODE_EVAL task_id={task_id} canary_flag={canary_flag} canary_raw={canary_raw} enforce_env={enforce_env} effective_mode={effective_mode}')
                        write_shadow({'event':'mode_eval','task_id':task_id,'canary_flag':canary_flag,'canary_raw':str(canary_raw),'enforce_env':enforce_env,'mode':effective_mode,'ts':time.time()})
                        # one-time debug for verify-* tasks: dump raw JSON to temp
                        try:
                            if isinstance(task_obj, dict) and str(task_id).startswith('verify-'):
                                dbg_path = RESULTS_DIR / f"{task_id}.popped.json"
                                dbg_path.write_text(json.dumps(obj))
                                logger.info(f'VERIFY_DEBUG wrote popped JSON to {dbg_path}')
                        except Exception:
                            logger.exception('failed writing verify debug')
                        # If enforce, call real llm path; otherwise simulate shadow processing
                        try:
                            if effective_mode=='enforce':
                                # call real llm client
                                from agent_hub import llm_client
                                logger.info(f'ENFORCE_CALL canary={canary_flag} task_id={task_id}')
                                try:
                                    # pass the actual task payload into llm_client
                                    res = llm_client.call_llm(task_obj if isinstance(task_obj,dict) else {}, task_id=task_id)
                                    # If call_llm returns normally, write result_written already handled inside llm_client
                                    write_shadow({'task_id':task_id,'event':'result_written','path':str(RESULTS_DIR / f"{task_id}.result.json"),'mode':'enforce','ts':time.time()})
                                    # remove queued file
                                    try:
                                        fname.unlink()
                                    except Exception:
                                        pass
                                except llm_client.RateLimitError as rle:
                                    # compute retry timing
                                    import random
                                    headers = getattr(rle,'headers',{}) or {}
                                    ra = headers.get('Retry-After') or headers.get('retry-after')
                                    try:
                                        ra_s = int(float(ra)) if ra is not None else None
                                    except Exception:
                                        ra_s = None
                                    # compute attempt and backoff
                                    attempt = (obj.get('attempt') or 0) + 1
                                    if ra_s:
                                        delay = ra_s
                                    else:
                                        base_delay = 30
                                        max_delay = 3600
                                        jitter = 0.1
                                        delay = min(max_delay, base_delay * (2 ** (attempt-1)))
                                        # apply jitter
                                        factor = random.uniform(1 - jitter, 1 + jitter)
                                        delay = int(delay * factor)
                                    next_retry = int(time.time()) + int(delay)
                                    # update payload for requeue: include attempt and next_retry_at
                                    try:
                                        payload_member = obj if isinstance(obj, dict) else {'task_id': task_id}
                                        payload_member['attempt'] = attempt
                                        payload_member['next_retry_at'] = next_retry
                                        payload_member['last_http_status'] = getattr(rle,'status',429)
                                        member = json.dumps(payload_member, separators=(',', ':'), sort_keys=True)
                                    except Exception:
                                        member = raw.decode('utf-8')
                                    # write retry artifact
                                    resobj = {'task_id':task_id,'status':'retry_scheduled','mode':'enforce','attempt':attempt,'next_retry_at':next_retry,'retry_after_s':ra_s,'last_http_status':rle.status,'error':str(rle),'ts':time.time()}
                                    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
                                    tmp = RESULTS_DIR / f"{task_id}.result.json.tmp"
                                    final = RESULTS_DIR / f"{task_id}.result.json"
                                    tmp.write_text(json.dumps(resobj))
                                    os.replace(str(tmp), str(final))
                                    write_shadow({'event':'rate_limited','task_id':task_id,'retry_after_s':ra_s,'next_retry_at':next_retry,'attempt':attempt,'ts':time.time()})
                                    # requeue into delayed ZSET with task_id-backed storage
                                    try:
                                        if r:
                                            zkey = CONFIG.get('durable_queue',{}).get('delayed_queue_key','governor:delayed')
                                            task_key = f"governor:task:{task_id}"
                                            # store updated payload_member under governor:task:<task_id>
                                            try:
                                                r.set(task_key, member)
                                                r.expire(task_key, 7 * 24 * 3600)
                                            except Exception:
                                                logger.exception('failed to write governor task record')
                                            # add to delayed ZSET using task_id as member with score=next_retry
                                            r.zadd(zkey, {task_id: next_retry})
                                    except Exception:
                                        logger.exception('failed to schedule delayed retry')
                                except Exception:
                                    logger.exception('failed processing popped item')
                            else:
                                # Shadow processing: record a small shadow result artifact for auditing
                                try:
                                    process_chunk_file(fname)
                                except Exception:
                                    logger.exception('shadow process_chunk_file failed')
                                # write a shadow result artifact regardless
                                try:
                                    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
                                    respath = RESULTS_DIR / f"{task_id}.result.json"
                                    tmp = RESULTS_DIR / f"{task_id}.result.json.tmp"
                                    tmp.write_text(json.dumps({'task_id':task_id,'status':'shadow_processed','mode':'shadow','ts':time.time()}))
                                    os.replace(str(tmp), str(respath))
                                    write_shadow({'task_id':task_id,'event':'shadow_result_written','path':str(respath),'mode':'shadow','ts':time.time()})
                                except Exception:
                                    logger.exception('failed writing shadow result artifact')
                        except Exception:
                            logger.exception('failed processing popped item')
                    except Exception:
                        logger.exception('failed processing popped item')
                else:
                    # nothing popped; sleep briefly
                    time.sleep(0.2)
            else:
                # fallback to filesystem-based loop
                for p in sorted(QUEUE_DIR.glob('*.json')):
                    try:
                        logger.info(f'found file {p.name} to process')
                        process_chunk_file(p)
                    except Exception:
                        logger.exception('chunk process failed')
                time.sleep(1)
        except Exception:
            logger.exception('worker loop unexpected error')
            # exit non-zero so container restarts
            raise

if __name__=='__main__':
    # ensure queue dir
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    SHADOW_REPORT.parent.mkdir(parents=True, exist_ok=True)
    worker_loop()
