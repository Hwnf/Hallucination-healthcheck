import os
import logging
import time
import json
logger = logging.getLogger('governor.llm_client')

class RateLimitError(Exception):
    def __init__(self, message, headers=None, status=429):
        super().__init__(message)
        self.headers = headers or {}
        self.status = status

def call_llm(payload, task_id=None):
    # Read enforce at call time; allow override if payload explicitly requests canary enforce
    enforce_env = os.getenv('GOVERNOR_ENFORCE','false').lower()=='true'
    # Strict gating: only allow external calls when GOVENOR_ENFORCE is true AND payload is canary
    enforce = enforce_env and bool(payload.get('canary'))
    OPENAI_KEY = os.getenv('OPENAI_API_KEY')
    if not enforce:
        logger.info(f"mode=shadow -> external_call_blocked task_id={task_id}")
        raise RuntimeError('external_call_blocked_in_shadow_mode')
    # Allowlist: require canary flag or env override
    if not (payload.get('canary') or enforce_env):
        logger.info(f"enforce enabled but task not in canary -> external_call_blocked task_id={task_id}")
        raise RuntimeError('not_in_canary')
    # Now proceed to call OpenAI (enforce mode)
    # test hook: simulate 429 only when GOVENOR_TEST_MODE enabled
    if os.getenv('GOVERNOR_TEST_MODE','false').lower()=='true' and payload.get('force_429'):
        headers={'Retry-After':'5'}
        raise RateLimitError('simulated 429', headers=headers)
    if not OPENAI_KEY:
        logger.error('OPENAI_API_KEY missing')
        raise RuntimeError('missing_api_key')
    # prefer new OpenAI v1 client
    try:
        from openai import OpenAI
        client = OpenAI(api_key=OPENAI_KEY)
    except Exception:
        client = None
    # tight max_output
    caps = {'small':64,'default':128,'large':256}
    max_out = payload.get('max_output_tokens', 128)
    max_out = min(max_out, caps.get('default',128))
    prompt = payload.get('prompt','')
    outdir = os.getenv('GOVERNOR_RESULTS_DIR') or './data/results'
    os.makedirs(outdir, exist_ok=True)

    logger.info(f'ENFORCE_CALL canary={payload.get("canary")} task_id={task_id}')
    start_time=time.time()
    # determine call shape conservatively; we'll set the actual endpoint used below
    call_shape = None
    used_endpoint = None
    simulated = False
    # If new client available, use it
    try:
        if client:
            # prefer chat.completions when the client exposes it
            used_endpoint = 'chat.completions'
            call_shape = 'chat_completions'
            resp = client.chat.completions.create(model=os.getenv('OPENAI_MODEL','gpt-5-mini'), messages=[{"role":"user","content":prompt}], max_completion_tokens=max_out)
            # prefer model_dump for pydantic-like objects, fallback to to_dict
            if hasattr(resp, 'model_dump'):
                resp_dict = resp.model_dump()
            elif hasattr(resp, 'to_dict'):
                resp_dict = resp.to_dict()
            else:
                try:
                    resp_dict = json.loads(json.dumps(resp))
                except Exception:
                    resp_dict = {'id': str(resp)}
        else:
            # fallback simulated response
            simulated = True
            used_endpoint = 'simulated'
            call_shape = 'simulated'
            logger.warning('OpenAI v1 client not available; using simulated response')
            resp_dict = {'id':'sim-'+str(int(time.time()*1000)),'choices':[{'message':{'role':'assistant','content':'Hello'}}]}
        logger.info(f'CALL_SHAPE={call_shape} endpoint={used_endpoint} task_id={task_id}')
        # extract assistant content safely and deterministically
        content = ''
        content_missing = True
        usage = None
        model_used = os.getenv('OPENAI_MODEL','gpt-5-mini')
        request_id = None
        raw_dump = None
        try:
            # resp may be a Pydantic-like object; prefer model_dump
            if hasattr(resp, 'model_dump'):
                rdict = resp.model_dump()
            elif hasattr(resp, 'to_dict'):
                rdict = resp.to_dict()
            else:
                rdict = resp_dict
            # optional raw dump (disabled by default to avoid PII)
            # raw_dump = rdict
            # choices-style
            if isinstance(rdict, dict):
                # try multiple shapes
                choices = rdict.get('choices')
                if choices and len(choices) > 0:
                    first = choices[0]
                    # message.content or text
                    if isinstance(first, dict):
                        msg = first.get('message') or first.get('delta') or first.get('text')
                        if isinstance(msg, dict):
                            content = msg.get('content','') or ''
                        elif isinstance(msg, str):
                            content = msg
                        else:
                            content = str(msg)
                    else:
                        content = str(first)
                else:
                    # fallback: look for top-level 'output' or 'text'
                    if 'output' in rdict and isinstance(rdict['output'], str):
                        content = rdict['output']
                    elif 'text' in rdict and isinstance(rdict['text'], str):
                        content = rdict['text']
                # usage
                if 'usage' in rdict:
                    usage = rdict.get('usage')
            else:
                # if rdict not dict, coerce
                content = str(rdict)
            # request id extraction
            try:
                raw = getattr(resp, 'raw_response', None)
                if raw and hasattr(raw, 'headers'):
                    headers = dict(raw.headers)
                    request_id = headers.get('x-request-id') or headers.get('request-id')
            except Exception:
                request_id = None
            # finalize content_missing
            if content:
                content_missing = False
            else:
                content_missing = True
        except Exception:
            content = ''
            content_missing = True
        latency_ms = int((time.time()-start_time)*1000)
        # compute prompt hash and config hash for auditability (optional)
        try:
            import hashlib
            prompt_sha256 = hashlib.sha256(prompt.encode('utf-8')).hexdigest() if isinstance(prompt, str) else None
        except Exception:
            prompt_sha256 = None
        result = {
            'task_id': task_id,
            'status': 'ok',
            'mode': 'enforce',
            'model': model_used,
            'content': content,
            'content_missing': content_missing,
            'usage': usage,
            'latency_ms': latency_ms,
            'request_id': request_id,
            'simulated': simulated,
            'endpoint': used_endpoint,
            'artifact_schema_version': 1,
            'prompt_sha256': prompt_sha256,
            'ts': time.time()
        }
        # write atomically
        tmp = os.path.join(outdir, f'{task_id}.result.json.tmp')
        final = os.path.join(outdir, f'{task_id}.result.json')
        with open(tmp,'w') as f:
            f.write(json.dumps(result))
        os.replace(tmp, final)
        logger.info(f'calling OpenAI done task_id={task_id}')
        return result
    except Exception as e:
        # Try to parse Retry-After from response-like objects
        ra = None
        try:
            hdrs = getattr(e, 'headers', {}) or {}
            ra = hdrs.get('Retry-After') or hdrs.get('retry-after')
        except Exception:
            ra = None
        logger.exception('openai call failed')
        # write an error result file so caller can see failure
        with open(os.path.join(outdir, f'{task_id}.result.json'),'w') as f:
            f.write(json.dumps({'task_id':task_id,'status':'error','error':str(e),'retry_after':ra,'ts':time.time()}))
        return {'task_id':task_id,'status':'error','error':str(e),'retry_after':ra}
