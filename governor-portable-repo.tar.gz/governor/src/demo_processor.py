import os
import json, math, time
from pathlib import Path
import sys
# prefer running from repo root; allow env overrides
# sys.path adjustments no longer required for portable layout
from agent_hub import queue_store
from agent_hub import token_bucket as tbmod

CONFIG_PATH=Path(os.getenv('GOVERNOR_CONFIG') or './config/governor_config.json')
CFG=json.loads(CONFIG_PATH.read_text()) if CONFIG_PATH.exists() else {}

SHADOW_REPORT=Path(os.getenv('GOVERNOR_SHADOW_REPORT') or CFG.get('startup',{}).get('shadow_report_path') or './data/logs/shadow_report.jsonl')
SHADOW_REPORT.parent.mkdir(parents=True, exist_ok=True)

# simulate chunking logic

def chunk_task(payload):
    # estimate includes output tokens
    est = payload['estimated_input_tokens'] + payload.get('max_output_tokens', CFG['default_max_output_tokens'])
    overhead = CFG.get('token_estimate_overhead',1.1)
    est_with_overhead = math.ceil(est * overhead)
    reserve_floor = CFG.get('reserve_floor_tokens', 5000)
    hard_cap = CFG.get('chunk_hard_cap_tokens', 125000)
    target_low = CFG.get('chunk_target_low_tokens',60000)
    target_high = CFG.get('chunk_target_high_tokens',80000)
    context_window = CFG.get('chunk_context_window_tokens')
    # remaining_budget_tokens: prefer token bucket available if present
    try:
        from agent_hub import token_bucket as tbmod
        tb = tbmod.TokenBucket(CFG.get('tpm',500000), capacity=CFG.get('bucket_capacity',500000)) if False else None
    except Exception:
        tb = None
    remaining_budget = None
    if TOKEN_BUCKET:
        try:
            remaining_budget = TOKEN_BUCKET.available()
        except Exception:
            remaining_budget = None
    # enforce max_estimated_tokens_per_request as an additional cap if present
    max_per_request = CFG.get('max_estimated_tokens_per_request')
    # use planner
    from agent_hub import chunking
    plan = chunking.plan_chunks(payload.get('task_id','unknown'), est, remaining_budget, reserve_floor, overhead, target_low=target_low, target_high=target_high, hard_cap_effective=hard_cap, context_window_tokens=context_window, context_frac=CFG.get('chunk_context_fraction',0.8))
    # If max_per_request present, ensure no chunk exceeds it (apply min)
    chunks = []
    for i,sz in enumerate(plan['chunks']):
        final_sz = sz
        if max_per_request:
            final_sz = min(final_sz, max_per_request)
        chunks.append({'est': final_sz, 'payload': dict(payload, chunk_index=i, total_chunks=len(plan['chunks']))})
    return est, est_with_overhead, chunks

# write shadow report line
def write_report(obj):
    with open(SHADOW_REPORT,'a') as f:
        f.write(json.dumps(obj) + "\n")

if __name__=='__main__':
    import uuid
    demo = {'task_id': 'demo-large-126592-'+str(uuid.uuid4()), 'estimated_input_tokens':126592, 'max_output_tokens':0, 'declared_cost':'high'}
    task_id = queue_store.enqueue_demo_task(demo)
    est, est_ov, chunks = chunk_task(demo)
    write_report({'task_id':task_id,'original_estimate':est,'estimate_with_overhead':est_ov,'num_chunks':len(chunks),'chunks':[c['est'] for c in chunks],'would_reserve':False,'reserve_floor_tokens':CFG['reserve_floor_tokens']})
    # also persist queue entries per chunk
    for i,c in enumerate(chunks):
        cid = f"{task_id}-chunk-{i}"
        queue_store.persist_task(cid, {'chunk_est':c['est'],'payload':c['payload'],'state':'queued'})
    print('demo enqueued', task_id, 'chunks', len(chunks))
