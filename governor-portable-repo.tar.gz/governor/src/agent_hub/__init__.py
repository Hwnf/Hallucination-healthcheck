"""
Compatibility shim so existing code that imports `agent_hub.*` continues to work
in the portable layout. This tries multiple import paths and exposes loaded
modules as attributes on this package and in sys.modules under agent_hub.<name>.
"""
import importlib
import sys
from types import ModuleType

_pkg = sys.modules.setdefault('agent_hub', ModuleType('agent_hub'))

_modules = [
    'cache', 'chunking', 'circuit_breaker', 'demo_processor', 'governor',
    'llm_client', 'queue_store', 'token_bucket', 'operator_sign', 'hmac_helper'
]

_loaded = []
for name in _modules:
    mod = None
    # try multiple candidate import paths in order
    candidates = [f'agent_hub.{name}', f'src.{name}', name]
    for cand in candidates:
        try:
            mod = importlib.import_module(cand)
            break
        except Exception:
            continue
    if mod:
        sys.modules[f'agent_hub.{name}'] = mod
        setattr(_pkg, name, mod)
        _loaded.append(name)

__all__ = _loaded
