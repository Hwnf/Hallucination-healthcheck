import json
from pathlib import Path
import uuid
import os

# config path preference: env -> config location inside repo -> fallback
CONFIG_PATH = Path(os.getenv('GOVERNOR_CONFIG') or './config/governor_config.json')
CFG = json.loads(CONFIG_PATH.read_text()) if CONFIG_PATH.exists() else {}

CHECKPOINT_DIR = Path(os.getenv('GOVERNOR_CHECKPOINT_DIR') or CFG.get('durable_queue',{}).get('host_checkpoint_dir') or './data/queue')
CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

USE_REDIS = CFG.get('durable_queue',{}).get('backend')=='redis'

if USE_REDIS:
    import redis
    REDIS_URL = os.environ.get('REDIS_URL','redis://localhost:6379/0')
    r = redis.from_url(REDIS_URL)


def persist_task_file(task_id, obj):
    p = CHECKPOINT_DIR / f"{task_id}.json"
    p.write_text(json.dumps(obj))


def load_task_file(task_id):
    p = CHECKPOINT_DIR / f"{task_id}.json"
    if p.exists():
        return json.loads(p.read_text())
    return None


def enqueue_demo_task(payload):
    task_id = payload.get('task_id') or str(uuid.uuid4())
    obj = {'task_id':task_id,'payload':payload}
    if USE_REDIS:
        # push to redis list and store a hash
        r.rpush(CFG.get('durable_queue',{}).get('redis_queue_key','governor:queue'), json.dumps(obj))
        r.hset(CFG.get('durable_queue',{}).get('redis_task_hash_prefix','governor:task:')+task_id, mapping={'payload':json.dumps(payload)})
    else:
        persist_task_file(task_id,obj)
    return task_id



def persist_task(task_id,obj):
    if USE_REDIS:
        # store as redis hash for task id and leave queue list as-is
        r.hset(CFG.get("durable_queue",{}).get("redis_task_hash_prefix","governor:task:")+task_id, mapping={"payload":json.dumps(obj.get("payload",""))})
    else:
        persist_task_file(task_id,obj)
