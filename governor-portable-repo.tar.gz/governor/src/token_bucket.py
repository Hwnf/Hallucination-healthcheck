import time
import threading

class TokenBucket:
    def __init__(self, tpm, capacity=None):
        self.tpm = tpm
        self.capacity = capacity or tpm
        self.tokens = self.capacity
        self.lock = threading.Lock()
        self.last = time.time()
    def _refill(self):
        now = time.time()
        elapsed = now - self.last
        self.last = now
        add = elapsed * (self.tpm/60.0)
        self.tokens = min(self.capacity, self.tokens + add)
    def reserve(self, amount):
        with self.lock:
            self._refill()
            if self.tokens >= amount:
                self.tokens -= amount
                return True
            return False
    def available(self):
        with self.lock:
            self._refill()
            return self.tokens
