import os
from pathlib import Path

# prefer environment override, then config-driven, then relative ./data/cache
_cache_env = os.getenv('GOVERNOR_CACHE_DIR')
if _cache_env:
    CACHE_DIR = Path(_cache_env)
else:
    CACHE_DIR = Path('./data/cache')

CACHE_DIR.mkdir(parents=True, exist_ok=True)

def cache_put(key: str, value: str):
    p = CACHE_DIR / (key + '.cache')
    p.write_text(value)

def cache_get(key: str):
    p = CACHE_DIR / (key + '.cache')
    if p.exists():
        return p.read_text()
    return None
