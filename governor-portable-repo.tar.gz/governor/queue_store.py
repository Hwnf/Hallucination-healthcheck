import json
from pathlib import Path
import uuid

CHECKPOINT_DIR = Path('/workspace/agent-hub/queue')
CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

def persist_task(task_id, obj):
    p = CHECKPOINT_DIR / f"{task_id}.json"
    p.write_text(json.dumps(obj))

def load_task(task_id):
    p = CHECKPOINT_DIR / f"{task_id}.json"
    if p.exists():
        return json.loads(p.read_text())
    return None

def enqueue_demo_task(payload):
    task_id = payload.get('task_id') or str(uuid.uuid4())
    obj = {'task_id':task_id,'payload':payload}
    persist_task(task_id,obj)
    return task_id
