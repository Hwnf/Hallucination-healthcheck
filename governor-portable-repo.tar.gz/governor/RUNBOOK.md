RUNBOOK — Governor Service

Purpose
This document contains operational runbook steps for the Governor (shadow & enforce) services.

Start/Stop
- Start both services:
  cd workspace/agent-hub
  docker compose -f docker-compose.governor.yml up -d

- Stop enforce worker only (instant rollback):
  docker compose -f docker-compose.governor.yml stop governor_enforce

Health checks
- STATUS log line (every ~30s): shows queue_len, delayed_len, enforce/test_mode
  docker logs --tail 5 governor | egrep STATUS

- Redis queue length:
  docker exec agent_hub_redis redis-cli LLEN governor:queue
  docker exec agent_hub_redis redis-cli LLEN governor:queue:enforce
  docker exec agent_hub_redis redis-cli ZCARD governor:delayed

Canary run (single)
1. Enqueue a canary to enforce queue from operator machine:
   docker exec agent_hub_redis redis-cli RPUSH governor:queue:enforce '{"payload":{"task_id":"canary-...","canary":true,...}}'
2. Verify enforce worker logs show MODE_EVAL ... effective_mode=enforce and ENFORCE_CALL.
3. Check result file in /workspace/agent-hub/results/<task_id>.result.json

Chunking / Large tasks
- Chunking is performed automatically for tasks with estimated_input_tokens > chunk_split_threshold (default 80000).
- Planner writes a shadow_report entry named event=chunk_plan with plan.meta

Troubleshooting
- If the enforce worker unexpectedly performs no external calls: ensure GOVERNOR_REDIS_QUEUE_KEY is set to governor:queue:enforce for the enforce service, and payload.canary=true.
- If Redis delayed zset grows: check RateLimit/Retry or llm_client RateLimit handling in logs and shadow_report.

Escalation
- Contact: Operator (automation)
- Provide: relevant shadow_report.jsonl lines, governor logs, and the result artifact.
