import json, math, time
from pathlib import Path
import sys
sys.path.append('/root/.openclaw/workspace/workspace')
import queue_store
import token_bucket as tbmod

CONFIG_PATH=Path('/workspace/agent-hub/config/governor_config.json')
CFG=json.loads(CONFIG_PATH.read_text())

SHADOW_REPORT=Path(CFG['startup']['shadow_report_path'])
SHADOW_REPORT.parent.mkdir(parents=True, exist_ok=True)

# simulate chunking logic

def chunk_task(payload):
    est = payload['estimated_input_tokens'] + payload.get('max_output_tokens', CFG['default_max_output_tokens'])
    max_per = CFG['max_estimated_tokens_per_request']
    overhead = CFG.get('token_estimate_overhead',1.0)
    est_with_overhead = math.ceil(est * overhead)
    chunks = []
    if est_with_overhead <= max_per:
        chunks.append({'est': est_with_overhead, 'payload': payload})
    else:
        # split into ceil(est/max_per) chunks
        n = math.ceil(est_with_overhead / max_per)
        base = math.floor(est_with_overhead / n)
        for i in range(n):
            e = base if i < n-1 else est_with_overhead - base*(n-1)
            chunks.append({'est': e, 'payload': dict(payload, chunk_index=i, total_chunks=n)})
    return est, est_with_overhead, chunks

# write shadow report line
def write_report(obj):
    with open(SHADOW_REPORT,'a') as f:
        f.write(json.dumps(obj) + "\n")

if __name__=='__main__':
    import uuid
    demo = {'task_id': 'demo-large-126592-'+str(uuid.uuid4()), 'estimated_input_tokens':126592, 'max_output_tokens':0, 'declared_cost':'high'}
    task_id = queue_store.enqueue_demo_task(demo)
    est, est_ov, chunks = chunk_task(demo)
    write_report({'task_id':task_id,'original_estimate':est,'estimate_with_overhead':est_ov,'num_chunks':len(chunks),'chunks':[c['est'] for c in chunks],'would_reserve':False,'reserve_floor_tokens':CFG['reserve_floor_tokens']})
    # also persist queue entries per chunk
    for i,c in enumerate(chunks):
        cid = f"{task_id}-chunk-{i}"
        queue_store.persist_task(cid, {'chunk_est':c['est'],'payload':c['payload'],'state':'queued'})
    print('demo enqueued', task_id, 'chunks', len(chunks))
