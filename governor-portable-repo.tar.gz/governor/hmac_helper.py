import hmac
import hashlib
import time
import os
import subprocess

# No module-level Redis client. Always use REDIS_URL at call time.

def sign_payload(secret: bytes, payload: bytes) -> str:
    return hmac.new(secret, payload, hashlib.sha256).hexdigest()


def verify_signature(secret: bytes, payload: bytes, signature: str) -> bool:
    expected = hmac.new(secret, payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def nonce_check(actor: str, nonce: str, ttl: int) -> bool:
    key = f"nonce:{actor}:{nonce}"
    redis_url = os.environ.get('REDIS_URL')
    if not redis_url:
        # No Redis configured: return False (treated as replay/failure by caller)
        return False
    try:
        import redis
        r = redis.from_url(redis_url, socket_connect_timeout=2, socket_timeout=2)
        res = r.set(key, 1, nx=True, ex=ttl)
        return bool(res)
    except Exception:
        # Attempt fallback via docker exec redis-cli
        try:
            cmd = ['docker','exec','agent_hub_redis','redis-cli','SET', key, '1', 'NX', 'EX', str(ttl)]
            out = subprocess.check_output(cmd, stderr=subprocess.STDOUT)
            return out.strip() != b''
        except Exception:
            return False


def current_ms():
    return int(time.time() * 1000)

# helper to load secret for an agent (file path)
def load_hmac_key(agent_id: str):
    # Respect HMAC_KEYS_PATH env var if set (mounted into container), else fallback to workspace keys
    base = os.getenv('HMAC_KEYS_PATH')
    if base:
        path = os.path.join(base, f'{agent_id}-hmac.key')
    else:
        path = os.path.join(os.path.dirname(__file__), '..', '..', 'keys', f'{agent_id}-hmac.key')
    if os.path.exists(path) and os.path.isfile(path):
        with open(path, 'rb') as f:
            v = f.read()
            if len(v) != 32:
                return None
            return v
    return None
