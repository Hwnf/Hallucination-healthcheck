CHANGELOG

All notable changes to this project should be documented in this file.

Unreleased
- Integrated adaptive chunk planner (60k-80k targets, 125k hard cap, overhead-aware).
- Wired planner into live worker split path; emits chunk_plan shadow_report entries.
- Added enforce worker (governor_enforce) consuming governor:queue:enforce and running with GOVERNOR_ENFORCE=true.
- Deterministic artifact schema for results; added scan_results_integrity tool.

2026-02-03 v0.1.0 (draft)
- Initial integration and Stage-6 rollout plumbing completed (shadow + enforce separation, single canary runs, adaptive chunking).
