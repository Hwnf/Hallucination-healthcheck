import time

class CircuitBreaker:
    def __init__(self, threshold=3, window=300, cooldown=120):
        self.threshold = threshold
        self.window = window
        self.cooldown = cooldown
        self.fail_times = []
        self.open_until = 0
    def record_failure(self):
        now=time.time()
        self.fail_times=[t for t in self.fail_times if now-t<=self.window]
        self.fail_times.append(now)
        if len(self.fail_times)>=self.threshold:
            self.open_until = now + self.cooldown
    def is_open(self):
        return time.time()<self.open_until
    def reset(self):
        self.fail_times=[]
        self.open_until=0
