import os
import logging
logger = logging.getLogger('governor.llm_client')

CONFIG_MODE = os.getenv('GOVERNOR_MODE') or 'shadow'

def call_llm(payload, task_id=None):
    """Proxy to external LLM. In shadow mode this must not call external services.
    It raises RuntimeError in shadow mode and logs mode=shadow -> external_call_blocked."""
    if CONFIG_MODE == 'shadow' or os.getenv('GOVERNOR_ENFORCE','false').lower()!='true':
        logger.info(f"mode=shadow -> external_call_blocked task_id={task_id}")
        raise RuntimeError('external_call_blocked_in_shadow_mode')
    # In enforce mode, actual call would be implemented here.
    raise NotImplementedError('LLM call not implemented in this demo')
