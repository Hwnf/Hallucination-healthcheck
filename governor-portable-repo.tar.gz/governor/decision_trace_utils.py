def add_check(trace: list, name: str, passed: bool):
    trace.append(f"{name}:{'pass' if passed else 'fail'}")

def trace_to_str(trace: list) -> str:
    return ';'.join(trace)

def compute_effective_cost(declared: str, inferred: str) -> str:
    order = {'low':0,'medium':1,'high':2}
    return declared if order[declared]>=order[inferred] else inferred
