ARCHITECTURE — Governor System (brief)

Components
- governor (shadow worker): consumes governor:queue (Redis). Always runs with GOVERNOR_ENFORCE=false; performs no external LLM calls.
- governor_enforce (enforce worker): consumes governor:queue:enforce (Redis). Runs with GOVERNOR_ENFORCE=true; only makes external calls when payload.canary==true.
- Redis durable queue: two primary lists (governor:queue and governor:queue:enforce) plus delayed zset (governor:delayed) and per-task storage governor:task:<task_id>.
- Token bucket (TOKEN_BUCKET): enforces runtime budget; planner reads TOKEN_BUCKET.available() to compute remaining_budget_tokens.
- Chunk planner (agent_hub/chunking.py): computes chunk sizes deterministically within target band (60–80k) and enforces hard cap (125k) with overhead.
- Shadow report (startup.shadow_report_path): JSONL audit log of events (popped, mode_eval, chunk_plan, result_written, etc.)

Dataflow
1. Call site dual-writes task envelope JSON into Redis:
   - Normal traffic -> governor:queue (shadow)
   - Canaries/percentage -> governor:queue:enforce (enforce)
2. Worker pops item, checks mode, writes popped report, and either executes enforcement (llm_client.call_llm) or processes in shadow.
3. For large tasks, the worker uses the planner to split into chunk files under /workspace/agent-hub/queue; those are then processed as separate chunk tasks.
4. Results are written to /workspace/agent-hub/results and shadow_report entries are emitted for auditing.

Safety
- llm_client requires both GOVENOR_ENFORCE=true and payload.canary==true to make external calls.
- Chunk planner prevents exceeding 125k after overhead by computing raw_runtime_cap = floor(runtime_cap_effective / overhead).
- Raw response dumps disabled by default to avoid PII retention.
