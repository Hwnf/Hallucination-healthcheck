import json, hmac, hashlib, time, uuid, requests, os
from pathlib import Path

KEY_PATH=Path(os.getenv('HMAC_KEYS_PATH','workspace/keys')) / 'agent-001-hmac.key'
if not KEY_PATH.exists():
    KEY_PATH.parent.mkdir(parents=True, exist_ok=True)
    import secrets
    KEY_PATH.write_bytes(secrets.token_bytes(32))

# read and strip key, keep as bytes
secret = KEY_PATH.read_bytes()
if len(secret) != 32:
    raise SystemExit('HMAC key must be 32 bytes')

def sign_bytes(key_bytes: bytes, body_bytes: bytes) -> str:
    return hmac.new(key_bytes, body_bytes, hashlib.sha256).hexdigest()


def make_signed_assign(url, task, reuse_payload=None):
    ts=int(time.time()*1000)
    nonce=str(uuid.uuid4())
    policy_version='v1'
    registry_version=1
    payload={
        'actor':'operator',
        'task':task,
        'ts':ts,
        'nonce':nonce,
        'policy_version':policy_version,
        'registry_version':registry_version
    }
    # deterministic JSON serialization
    body_bytes = json.dumps(payload, separators=(",",":"), sort_keys=True).encode('utf-8')
    sig = sign_bytes(secret, body_bytes)
    headers = {'X-Signature':sig,'Content-Type':'application/json'}
    r = requests.post(url, data=body_bytes, headers=headers)
    return r.status_code, r.text, payload, body_bytes, sig

if __name__=='__main__':
    url='http://localhost:8081/peer/assign'
    task={'declared_cost':'low','risk_class':'low','estimated_input_tokens':1000,'expected_tool_calls':0,'attachments_total_bytes':0,'retry_budget':0}
    code,text,payload,body,sig = make_signed_assign(url,task)
    print(code,text)
    # try replay: send the exact same bytes and signature
    headers = {'X-Signature':sig,'Content-Type':'application/json'}
    code2 = requests.post(url, data=body, headers=headers)
    print('replay',code2.status_code,code2.text)
