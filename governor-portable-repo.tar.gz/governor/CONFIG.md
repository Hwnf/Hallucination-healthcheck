CONFIG reference — governor_config.json (key highlights)

Important fields (defaults shown where available)
- reserve_floor_tokens: 5000
  Minimum reserve to keep in token pool; planner uses this when computing runtime budget cap.

- token_estimate_overhead: 1.1
  Overhead multiplier applied to estimated tokens when computing caps.

- chunk_split_threshold: 80000
  Trigger threshold for using planner to split tasks; tasks with estimated_input_tokens > threshold are split.

- chunk_target_low_tokens / chunk_target_high_tokens: 60000 / 80000
  Target band for deterministic chunk sizing.

- chunk_hard_cap_tokens: 125000
  Hard effective cap in tokens; planner enforces raw_runtime_cap = floor(hard_cap / overhead).

- max_estimated_tokens_per_request: 113636
  Kept as a per-chunk cap (NOT the split trigger). You can change or remove; planner also enforces hard cap.

- startup.shadow_report_path: ./data/logs/shadow_report.jsonl (use GOVERNOR_SHADOW_REPORT to override)
  Path where the worker writes audit lines (popped, mode_eval, chunk_plan, result_written, etc.)

- durable_queue.redis_queue_key: governor:queue
  Default Redis queue for shadow worker. For enforce worker, set GOVERNOR_REDIS_QUEUE_KEY env to governor:queue:enforce (or provide a separate config file for enforce worker).

Notes
- Prefer configuring sensitive values (OPENAI_API_KEY) as environment variables or via a secrets manager.
- To change chunk behavior, update chunk_split_threshold, chunk_target_* and chunk_hard_cap_tokens.
