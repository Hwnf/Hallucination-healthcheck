import os
import json
import logging
import time
from pathlib import Path

logger = logging.getLogger('governor')
logging.basicConfig(level=logging.INFO)
CONFIG_PATH = Path('/workspace/agent-hub/config/governor_config.json')
if CONFIG_PATH.exists():
    CONFIG = json.loads(CONFIG_PATH.read_text())
else:
    CONFIG = {}

MODE = CONFIG.get('enforcement_mode','shadow')
QUEUE_DIR = Path(CONFIG.get('durable_queue',{}).get('host_checkpoint_dir','/workspace/agent-hub/queue'))
SHADOW_REPORT = Path(CONFIG.get('startup',{}).get('shadow_report_path','/workspace/agent-hub/shadow_report.jsonl'))
RESULTS_DIR = Path('/workspace/agent-hub/results')
TOKEN_BUCKET = None
try:
    from token_bucket import TokenBucket
    TOKEN_BUCKET = TokenBucket(CONFIG.get('tpm',500000), capacity=CONFIG.get('bucket_capacity',500000))
except Exception:
    TOKEN_BUCKET = None

# ensure dirs exist at startup
QUEUE_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
SHADOW_REPORT.parent.mkdir(parents=True, exist_ok=True)

def write_shadow(obj):
    with open(SHADOW_REPORT,'a') as f:
        f.write(json.dumps(obj)+"\n")

def process_chunk_file(p:Path):
    # read chunk
    obj = json.loads(p.read_text())
    est = obj.get('chunk_est')
    task = obj.get('payload')
    task_id = task.get('task_id')
    state_file = p.with_suffix('.status')
    # check reserve_floor_tokens
    reserve_floor = CONFIG.get('reserve_floor_tokens',0)
    if TOKEN_BUCKET:
        avail = TOKEN_BUCKET.available()
        would_reserve = (avail >= est and (avail-est)>=reserve_floor)
    else:
        would_reserve = False
    # write running status
    state = {'task_id':task_id,'chunk':p.name,'state':'running' if would_reserve else 'paused','est':est,'would_reserve':would_reserve,'ts':time.time()}
    state_file.write_text(json.dumps(state))
    write_shadow({'task_id':task_id,'chunk':p.name,'would_reserve':would_reserve,'est':est,'avail': TOKEN_BUCKET.available() if TOKEN_BUCKET else None,'mode':MODE})
    if would_reserve and TOKEN_BUCKET:
        # reserve and simulate processing
        TOKEN_BUCKET.reserve(est)
        # simulate work
        time.sleep(0.1)
        # mark done
        state['state']='done'
        state['finished_at']=time.time()
        state_file.write_text(json.dumps(state))
        # move or remove chunk file
        p.unlink()
    else:
        # leave file queued for later
        pass

def worker_loop():
    logger.info(f'governor worker starting mode={MODE}')
    while True:
        for p in sorted(QUEUE_DIR.glob('*.json')):
            try:
                process_chunk_file(p)
            except Exception:
                logger.exception('chunk process failed')
        time.sleep(1)

if __name__=='__main__':
    # ensure queue dir
    QUEUE_DIR.mkdir(parents=True, exist_ok=True)
    worker_loop()
