RELEASE & TAGGING

When ready to cut a release:

1. Ensure working tree is clean and tests pass.
2. Create a semantic version tag, e.g. v0.1.0:
   git tag -a v0.1.0 -m "Release v0.1.0: adaptive chunking + enforce worker"
   git push origin v0.1.0

3. Create release notes in CHANGELOG.md and attach the tag.

Notes:
- Keep secrets out of the repo.
- Use CI to build and publish images from tagged commits.
