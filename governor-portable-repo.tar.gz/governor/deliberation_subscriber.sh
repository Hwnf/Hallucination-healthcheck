#!/bin/bash
# Simple subscriber: subscribes to Redis channel p2p:deliberation and appends JSON messages to a transcript file.
TRANS_DIR="/root/.openclaw/workspace/workspace/agent-hub"
mkdir -p "$TRANS_DIR"
TS=$(date +%Y%m%dT%H%M%S)
OUT="$TRANS_DIR/deliberation_live_${TS}.txt"
# Header
echo "Deliberation live transcript" > "$OUT"
echo "Started: $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "$OUT"
echo "---" >> "$OUT"
# Subscribe via the redis container and append messages
# This will run until killed; run under nohup or systemd for persistence
docker exec agent_hub_redis redis-cli SUBSCRIBE p2p:deliberation | while read -r line; do
  # Simple append; do not include binary data
  echo "$(date -u +%Y-%m-%dT%H:%M:%SZ) | $line" >> "$OUT"
done
