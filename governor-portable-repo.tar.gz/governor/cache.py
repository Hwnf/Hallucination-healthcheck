import os
from pathlib import Path

CACHE_DIR = Path('/workspace/agent-hub/cache')
CACHE_DIR.mkdir(parents=True, exist_ok=True)

def cache_put(key: str, value: str):
    p = CACHE_DIR / (key + '.cache')
    p.write_text(value)

def cache_get(key: str):
    p = CACHE_DIR / (key + '.cache')
    if p.exists():
        return p.read_text()
    return None
