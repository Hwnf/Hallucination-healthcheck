#!/usr/bin/env python3
"""
Start a deliberation session only with council members.
Usage: python3 start_deliberation.py "Agenda text..."
This script enforces that only agents listed in council.txt may be included.
It publishes start/message/end events to Redis channel p2p:deliberation and
records the transcript to workspace/agent-hub/deliberation_<ts>.txt
"""
import sys, time, json, os
try:
    import redis
except Exception:
    print('Missing redis library. Install in a venv or run from host with redis-cli available.')
    sys.exit(1)

ROOM='p2p:deliberation'
COUNCIL_FILE='council.txt'
TRANS_DIR='.'

if not os.path.exists(COUNCIL_FILE):
    print('Council file not found:', COUNCIL_FILE)
    sys.exit(1)

with open(COUNCIL_FILE) as f:
    council=[l.strip() for l in f.readlines() if l.strip()]

if len(sys.argv)<2:
    print('Usage: start_deliberation.py "Agenda text"')
    sys.exit(1)

agenda=sys.argv[1]

r=redis.Redis()

start_event={'type':'start','participants':council,'agenda':agenda,'ts':time.time()}
r.publish(ROOM,json.dumps(start_event))

# record transcript locally
ts=int(time.time())
fname=f'deliberation_live_{ts}.txt'
with open(os.path.join(TRANS_DIR,fname),'w') as out:
    out.write('Deliberation live transcript\n')
    out.write('Agenda: '+agenda+'\n')
    out.write('Participants: '+', '.join(council)+'\n')
    out.write('\n--- START ---\n')

print('Deliberation started with council:', council)
print('Transcript file:', fname)
print('Published start event to', ROOM)

# Note: actual live message capture must be done by a subscriber that appends to the file.
